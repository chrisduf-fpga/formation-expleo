--Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
--Date        : Wed Oct  7 04:01:41 2026
--Host        : galileo running 64-bit Ubuntu 20.04.6 LTS
--Command     : generate_target axis_rgb888_to_rgb8_bd_wrapper.bd
--Design      : axis_rgb888_to_rgb8_bd_wrapper
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity axis_rgb888_to_rgb8_bd_wrapper is
  port (
    M_AXIS_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    M_AXIS_tlast : out STD_LOGIC;
    M_AXIS_tready : in STD_LOGIC;
    M_AXIS_tuser : out STD_LOGIC;
    M_AXIS_tvalid : out STD_LOGIC;
    S_AXIS_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    S_AXIS_tlast : in STD_LOGIC;
    S_AXIS_tready : out STD_LOGIC;
    S_AXIS_tuser : in STD_LOGIC;
    S_AXIS_tvalid : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC
  );
end axis_rgb888_to_rgb8_bd_wrapper;

architecture STRUCTURE of axis_rgb888_to_rgb8_bd_wrapper is
  component axis_rgb888_to_rgb8_bd is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    S_AXIS_tdata : in STD_LOGIC_VECTOR ( 23 downto 0 );
    S_AXIS_tlast : in STD_LOGIC;
    S_AXIS_tuser : in STD_LOGIC;
    S_AXIS_tvalid : in STD_LOGIC;
    S_AXIS_tready : out STD_LOGIC;
    M_AXIS_tdata : out STD_LOGIC_VECTOR ( 7 downto 0 );
    M_AXIS_tlast : out STD_LOGIC;
    M_AXIS_tuser : out STD_LOGIC;
    M_AXIS_tvalid : out STD_LOGIC;
    M_AXIS_tready : in STD_LOGIC
  );
  end component axis_rgb888_to_rgb8_bd;
begin
axis_rgb888_to_rgb8_bd_i: component axis_rgb888_to_rgb8_bd
     port map (
      M_AXIS_tdata(7 downto 0) => M_AXIS_tdata(7 downto 0),
      M_AXIS_tlast => M_AXIS_tlast,
      M_AXIS_tready => M_AXIS_tready,
      M_AXIS_tuser => M_AXIS_tuser,
      M_AXIS_tvalid => M_AXIS_tvalid,
      S_AXIS_tdata(23 downto 0) => S_AXIS_tdata(23 downto 0),
      S_AXIS_tlast => S_AXIS_tlast,
      S_AXIS_tready => S_AXIS_tready,
      S_AXIS_tuser => S_AXIS_tuser,
      S_AXIS_tvalid => S_AXIS_tvalid,
      aclk => aclk,
      aresetn => aresetn
    );
end STRUCTURE;
