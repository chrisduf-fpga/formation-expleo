--Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2020.2 (lin64) Build 3064766 Wed Nov 18 09:12:47 MST 2020
--Date        : Wed Oct  7 01:16:46 2026
--Host        : galileo running 64-bit Ubuntu 20.04.6 LTS
--Command     : generate_target axis_rgb8_to_rgb888_bd.bd
--Design      : axis_rgb8_to_rgb888_bd
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity axis_rgb8_to_rgb888_bd is
  port (
    M_AXIS_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    M_AXIS_tlast : out STD_LOGIC;
    M_AXIS_tready : in STD_LOGIC;
    M_AXIS_tuser : out STD_LOGIC;
    M_AXIS_tvalid : out STD_LOGIC;
    S_AXIS_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    S_AXIS_tlast : in STD_LOGIC;
    S_AXIS_tready : out STD_LOGIC;
    S_AXIS_tuser : in STD_LOGIC;
    S_AXIS_tvalid : in STD_LOGIC;
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of axis_rgb8_to_rgb888_bd : entity is "axis_rgb8_to_rgb888_bd,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=axis_rgb8_to_rgb888_bd,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=1,numReposBlks=1,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,synth_mode=OOC_per_IP}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of axis_rgb8_to_rgb888_bd : entity is "axis_rgb8_to_rgb888_bd.hwdef";
end axis_rgb8_to_rgb888_bd;

architecture STRUCTURE of axis_rgb8_to_rgb888_bd is
  component axis_rgb8_to_rgb888_bd_axis_rgb8_to_rgb888_0_0 is
  port (
    aclk : in STD_LOGIC;
    aresetn : in STD_LOGIC;
    s_axis_tready : out STD_LOGIC;
    s_axis_tvalid : in STD_LOGIC;
    s_axis_tdata : in STD_LOGIC_VECTOR ( 7 downto 0 );
    s_axis_tuser : in STD_LOGIC;
    s_axis_tlast : in STD_LOGIC;
    m_axis_tready : in STD_LOGIC;
    m_axis_tvalid : out STD_LOGIC;
    m_axis_tdata : out STD_LOGIC_VECTOR ( 23 downto 0 );
    m_axis_tuser : out STD_LOGIC;
    m_axis_tlast : out STD_LOGIC
  );
  end component axis_rgb8_to_rgb888_bd_axis_rgb8_to_rgb888_0_0;
  signal S_AXIS_1_TDATA : STD_LOGIC_VECTOR ( 7 downto 0 );
  signal S_AXIS_1_TLAST : STD_LOGIC;
  signal S_AXIS_1_TREADY : STD_LOGIC;
  signal S_AXIS_1_TUSER : STD_LOGIC;
  signal S_AXIS_1_TVALID : STD_LOGIC;
  signal aclk_1 : STD_LOGIC;
  signal aresetn_1 : STD_LOGIC;
  signal axis_rgb8_to_rgb888_0_M_AXIS_TDATA : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal axis_rgb8_to_rgb888_0_M_AXIS_TLAST : STD_LOGIC;
  signal axis_rgb8_to_rgb888_0_M_AXIS_TREADY : STD_LOGIC;
  signal axis_rgb8_to_rgb888_0_M_AXIS_TUSER : STD_LOGIC;
  signal axis_rgb8_to_rgb888_0_M_AXIS_TVALID : STD_LOGIC;
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of M_AXIS_tlast : signal is "xilinx.com:interface:axis:1.0 M_AXIS TLAST";
  attribute X_INTERFACE_INFO of M_AXIS_tready : signal is "xilinx.com:interface:axis:1.0 M_AXIS TREADY";
  attribute X_INTERFACE_INFO of M_AXIS_tuser : signal is "xilinx.com:interface:axis:1.0 M_AXIS TUSER";
  attribute X_INTERFACE_INFO of M_AXIS_tvalid : signal is "xilinx.com:interface:axis:1.0 M_AXIS TVALID";
  attribute X_INTERFACE_INFO of S_AXIS_tlast : signal is "xilinx.com:interface:axis:1.0 S_AXIS TLAST";
  attribute X_INTERFACE_INFO of S_AXIS_tready : signal is "xilinx.com:interface:axis:1.0 S_AXIS TREADY";
  attribute X_INTERFACE_INFO of S_AXIS_tuser : signal is "xilinx.com:interface:axis:1.0 S_AXIS TUSER";
  attribute X_INTERFACE_INFO of S_AXIS_tvalid : signal is "xilinx.com:interface:axis:1.0 S_AXIS TVALID";
  attribute X_INTERFACE_INFO of aclk : signal is "xilinx.com:signal:clock:1.0 CLK.ACLK CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of aclk : signal is "XIL_INTERFACENAME CLK.ACLK, ASSOCIATED_BUSIF S_AXIS:M_AXIS, ASSOCIATED_RESET aresetn, CLK_DOMAIN axis_rgb8_to_rgb888_bd_aclk, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.000";
  attribute X_INTERFACE_INFO of aresetn : signal is "xilinx.com:signal:reset:1.0 RST.ARESETN RST";
  attribute X_INTERFACE_PARAMETER of aresetn : signal is "XIL_INTERFACENAME RST.ARESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW";
  attribute X_INTERFACE_INFO of M_AXIS_tdata : signal is "xilinx.com:interface:axis:1.0 M_AXIS TDATA";
  attribute X_INTERFACE_PARAMETER of M_AXIS_tdata : signal is "XIL_INTERFACENAME M_AXIS, CLK_DOMAIN axis_rgb8_to_rgb888_bd_aclk, FREQ_HZ 50000000, HAS_TKEEP 0, HAS_TLAST 1, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.000, TDATA_NUM_BYTES 3, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 1";
  attribute X_INTERFACE_INFO of S_AXIS_tdata : signal is "xilinx.com:interface:axis:1.0 S_AXIS TDATA";
  attribute X_INTERFACE_PARAMETER of S_AXIS_tdata : signal is "XIL_INTERFACENAME S_AXIS, CLK_DOMAIN axis_rgb8_to_rgb888_bd_aclk, FREQ_HZ 50000000, HAS_TKEEP 0, HAS_TLAST 1, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.000, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 1";
begin
  M_AXIS_tdata(23 downto 0) <= axis_rgb8_to_rgb888_0_M_AXIS_TDATA(23 downto 0);
  M_AXIS_tlast <= axis_rgb8_to_rgb888_0_M_AXIS_TLAST;
  M_AXIS_tuser <= axis_rgb8_to_rgb888_0_M_AXIS_TUSER;
  M_AXIS_tvalid <= axis_rgb8_to_rgb888_0_M_AXIS_TVALID;
  S_AXIS_1_TDATA(7 downto 0) <= S_AXIS_tdata(7 downto 0);
  S_AXIS_1_TLAST <= S_AXIS_tlast;
  S_AXIS_1_TUSER <= S_AXIS_tuser;
  S_AXIS_1_TVALID <= S_AXIS_tvalid;
  S_AXIS_tready <= S_AXIS_1_TREADY;
  aclk_1 <= aclk;
  aresetn_1 <= aresetn;
  axis_rgb8_to_rgb888_0_M_AXIS_TREADY <= M_AXIS_tready;
axis_rgb8_to_rgb888_0: component axis_rgb8_to_rgb888_bd_axis_rgb8_to_rgb888_0_0
     port map (
      aclk => aclk_1,
      aresetn => aresetn_1,
      m_axis_tdata(23 downto 0) => axis_rgb8_to_rgb888_0_M_AXIS_TDATA(23 downto 0),
      m_axis_tlast => axis_rgb8_to_rgb888_0_M_AXIS_TLAST,
      m_axis_tready => axis_rgb8_to_rgb888_0_M_AXIS_TREADY,
      m_axis_tuser => axis_rgb8_to_rgb888_0_M_AXIS_TUSER,
      m_axis_tvalid => axis_rgb8_to_rgb888_0_M_AXIS_TVALID,
      s_axis_tdata(7 downto 0) => S_AXIS_1_TDATA(7 downto 0),
      s_axis_tlast => S_AXIS_1_TLAST,
      s_axis_tready => S_AXIS_1_TREADY,
      s_axis_tuser => S_AXIS_1_TUSER,
      s_axis_tvalid => S_AXIS_1_TVALID
    );
end STRUCTURE;
